package per.pqy.apktool;

public class myThread extends Thread {
	int tasknum;
	public myThread(int num){
		tasknum=num;
	}

}
