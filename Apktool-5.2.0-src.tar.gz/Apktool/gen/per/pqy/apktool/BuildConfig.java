/** Automatically generated file. DO NOT MODIFY */
package per.pqy.apktool;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}